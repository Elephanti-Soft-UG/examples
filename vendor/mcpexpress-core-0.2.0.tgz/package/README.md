# @mcpexpress/core

Define MCP tools, prompts and skills for the MCP Express runtime. This package only describes them; the
runtime loads them, validates input, applies limits and serves them over MCP.

```ts
import { z } from "zod";
import { defineTool } from "@mcpexpress/core";

export const getWeather = defineTool({
  name: "get_weather",
  description: "Current weather for a city",
  input: z.object({ city: z.string() }),
  execute: async ({ city }, { signal }) => `It is sunny in ${city}`,
});
```

- Export one or more tools from each file (named or default exports).
- Return a string, any JSON value, or a full `ToolResult`. With an `output` schema, return
  data matching it. Throw to signal an error.
- `input` / `output` must be plain `z.object({...})` (Zod 3.25.28+ or Zod 4).

## Environment variables

Tools read configuration from `process.env` as usual (use `dotenv` for local runs). List the
variables a tool cannot run without in `env`, names only:

```ts
export const getWeather = defineTool({
  name: "get_weather",
  description: "Current weather for a city",
  input: z.object({ city: z.string() }),
  env: ["OPENWEATHER_API_KEY"],
  execute: async ({ city }) => { /* reads process.env.OPENWEATHER_API_KEY */ },
});
```

Before every call the runtime checks that each listed variable is set and non-empty. If any are
missing it returns an error naming them and `execute()` does not run. Leave optional variables
out of the list. `getMissingEnv(tool, env?)` runs the same check, against `process.env` by
default, for local scripts.

## Prompts

Prompts are reusable message templates that users pick from the client (often as slash
commands). Define them with `definePrompt` and export them alongside your tools:

```ts
import { z } from "zod";
import { definePrompt } from "@mcpexpress/core";

export const reviewCode = definePrompt({
  name: "review_code",
  title: "Review code",
  description: "Review a code snippet for bugs, readability and performance.",
  args: z.object({
    code: z.string().min(1).describe("The code to review"),
    focus: z.enum(["bugs", "style", "performance"]).default("bugs").describe("What to focus on"),
  }),
  render: ({ code, focus }) => [
    { role: "user", content: { type: "text", text: `Review this code, focusing on ${focus}:\n\n${code}` } },
  ],
});
```

- `args` is optional and must be a plain `z.object({...})`. Clients send every argument as a
  string, so fields must accept strings (`z.string()`, `z.enum`, `.optional()`, `.default()`,
  `z.string().transform(...)`); TypeScript rejects `z.number()` and similar.
- `render` returns a string (one `user` message), an array of messages, or
  `{ description?, messages }`. Throw to signal an error.
- `description`, `title` and `env` work as they do for tools; `description` is optional.

## Skills

Skills are instructions (plus optional supporting files) that teach an agent a workflow, served
through the [MCP Skills extension](https://modelcontextprotocol.io/extensions/skills/overview)
(`io.modelcontextprotocol/skills`). Define them with `defineSkill` and export them alongside your
tools; the fields follow the [Agent Skills specification](https://agentskills.io/specification):

```ts
import { defineSkill } from "@mcpexpress/core";

export const codeReview = defineSkill({
  name: "code-review",
  description: "Review a pull request for bugs and readability. Use when the user asks for a code review.",
  license: "MIT",
  metadata: { author: "acme", version: "1.0" },
  instructions: "# Code review\n\nGo through `references/checklist.md` item by item.\n",
  files: {
    "references/checklist.md": "- Null handling\n- Error paths\n- Tests\n",
  },
});
// skill://code-review/SKILL.md and skill://code-review/references/checklist.md
```

- `name`: 1-64 lowercase letters, digits and single hyphens. `description` (max 1024 characters)
  is what the agent reads to decide when to load the skill.
- `instructions` is the markdown body of SKILL.md. The SKILL.md file, frontmatter included, is
  generated from these fields, so it always matches what `skills/list` reports.
- `files` maps relative paths to text (or `{ text, mimeType }`). Refer to them from the
  instructions by relative path. Limits: 512 files and 16 MiB per skill, SKILL.md included.
- `path` groups skills: `path: "acme/billing"` with `name: "refunds"` is served at
  `skill://acme/billing/refunds/SKILL.md`.
- Optional `license`, `compatibility`, `metadata` (string values) and `allowedTools`
  (`allowed-tools`, space-separated; hosts ignore it unless the user approves it).
- Content is static: every file is fixed at definition time, so manifests carry digests.

## Packaging tools for upload

Bundle to JavaScript (inline zod and this package), then zip:

```
my-tools.zip
├── manifest.json   { "name": "...", "version": "...", "tools": ["./tools/get_weather.js"] }
└── tools/get_weather.js
```

## Runtime checklist

1. Unzip safely (reject `..` paths, absolute paths, symlinks; cap size and file count).
2. Read `manifest.json`; `import()` each listed file.
3. For every export: `isTool(x)` then `isSupportedToolVersion(x)`; reject with a clear message otherwise.
4. Reject duplicate tool names across all loaded zips.
5. Convert `input`/`output` to JSON Schema for `tools/list` (dispatch on `_zod` vs `_def`:
   Zod 4 `z.toJSONSchema`, Zod 3 `zod-to-json-schema`).
6. On `tools/call`: if `getMissingEnv(tool, serverEnv)` is non-empty, return an MCP error naming
   the variables without calling `execute`. Then `await tool.input["~standard"].validate(args)`; on `issues`, return an MCP error.
7. Call `execute(value, { signal })` with a timeout. Normalise the result: object with a
   `content` array is a `ToolResult`, otherwise JSON-stringify into a text item. Convert thrown
   errors to `isError: true`. Add a `default` branch when switching on `ToolContent.type`.
8. Prompts: filter exports with `isPrompt(x)` + `isSupportedPromptVersion(x)` and reject duplicate
   names. For `prompts/list`, derive `arguments` from the `args` object shape (field name,
   `.describe()` text, `required` unless optional/defaulted). On `prompts/get`: check
   `getMissingEnv`, validate with `prompt.args["~standard"].validate(args)`, call
   `render(value, { signal })`, then normalise: string → one `user` text message, array →
   `messages`, object with a `messages` array → the result as is.
9. Skills: filter exports with `isSkill(x)` + `isSupportedSkillVersion(x)` and reject duplicate
   `uri`s (names may repeat under different `path`s). Declare `capabilities.resources` and
   `capabilities.extensions[SKILLS_EXTENSION_ID]` (`{ directoryRead: true }` if you implement
   `resources/directory/read`). Compute `getSkillEntry(skill)` once per skill. `skills/list`
   returns `{ resultType: "complete", skills: [entries], ttlMs, cacheScope }` (never split an entry
   across pages); `skills/get` returns `{ resultType: "complete", skill: entry, ttlMs, cacheScope }`
   or error `-32602` for an unknown `uri`. `resources/read` serves `getSkillFiles(skill)` exactly
   (`text` unchanged, so digests match); unknown skill files get `-32602`. Directories (the skill
   root and every subfolder) are `inode/directory` resources without a trailing slash.
10. Run uploaded code isolated (worker/child process with no secrets, or a container).

## Releasing

`npm run build && npm test`, then `npm pack --dry-run` to inspect the tarball.
Publish from CI with `npm publish --provenance --access public`.
Stay on `0.x` until real tools run in production. Breaking contract changes bump `apiVersion`.
