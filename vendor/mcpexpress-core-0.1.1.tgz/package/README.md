# @mcpexpress/core

Define MCP tools and prompts for the MCP Express runtime. This package only describes them; the
runtime loads them, validates input, applies limits and serves them over MCP.

```ts
import { z } from "zod";
import { defineTool } from "@mcpexpress/core";

export const getWeather = defineTool({
  name: "get_weather",
  description: "Current weather for a city",
  input: z.object({ city: z.string() }),
  execute: async ({ city }, { signal }) => `It is sunny in ${city}`,
});
```

- Export one or more tools from each file (named or default exports).
- Return a string, any JSON value, or a full `ToolResult`. With an `output` schema, return
  data matching it. Throw to signal an error.
- `input` / `output` must be plain `z.object({...})` (Zod 3.25.28+ or Zod 4).

## Environment variables

Tools read configuration from `process.env` as usual (use `dotenv` for local runs). List the
variables a tool cannot run without in `env`, names only:

```ts
export const getWeather = defineTool({
  name: "get_weather",
  description: "Current weather for a city",
  input: z.object({ city: z.string() }),
  env: ["OPENWEATHER_API_KEY"],
  execute: async ({ city }) => { /* reads process.env.OPENWEATHER_API_KEY */ },
});
```

Before every call the runtime checks that each listed variable is set and non-empty. If any are
missing it returns an error naming them and `execute()` does not run. Leave optional variables
out of the list. `getMissingEnv(tool, env?)` runs the same check, against `process.env` by
default, for local scripts.

## Prompts

Prompts are reusable message templates that users pick from the client (often as slash
commands). Define them with `definePrompt` and export them alongside your tools:

```ts
import { z } from "zod";
import { definePrompt } from "@mcpexpress/core";

export const reviewCode = definePrompt({
  name: "review_code",
  title: "Review code",
  description: "Review a code snippet for bugs, readability and performance.",
  args: z.object({
    code: z.string().min(1).describe("The code to review"),
    focus: z.enum(["bugs", "style", "performance"]).default("bugs").describe("What to focus on"),
  }),
  render: ({ code, focus }) => [
    { role: "user", content: { type: "text", text: `Review this code, focusing on ${focus}:\n\n${code}` } },
  ],
});
```

- `args` is optional and must be a plain `z.object({...})`. Clients send every argument as a
  string, so fields must accept strings (`z.string()`, `z.enum`, `.optional()`, `.default()`,
  `z.string().transform(...)`); TypeScript rejects `z.number()` and similar.
- `render` returns a string (one `user` message), an array of messages, or
  `{ description?, messages }`. Throw to signal an error.
- `description`, `title` and `env` work as they do for tools; `description` is optional.

## Packaging tools for upload

Bundle to JavaScript (inline zod and this package), then zip:

```
my-tools.zip
├── manifest.json   { "name": "...", "version": "...", "tools": ["./tools/get_weather.js"] }
└── tools/get_weather.js
```

## Runtime checklist

1. Unzip safely (reject `..` paths, absolute paths, symlinks; cap size and file count).
2. Read `manifest.json`; `import()` each listed file.
3. For every export: `isTool(x)` then `isSupportedToolVersion(x)`; reject with a clear message otherwise.
4. Reject duplicate tool names across all loaded zips.
5. Convert `input`/`output` to JSON Schema for `tools/list` (dispatch on `_zod` vs `_def`:
   Zod 4 `z.toJSONSchema`, Zod 3 `zod-to-json-schema`).
6. On `tools/call`: if `getMissingEnv(tool, serverEnv)` is non-empty, return an MCP error naming
   the variables without calling `execute`. Then `await tool.input["~standard"].validate(args)`; on `issues`, return an MCP error.
7. Call `execute(value, { signal })` with a timeout. Normalise the result: object with a
   `content` array is a `ToolResult`, otherwise JSON-stringify into a text item. Convert thrown
   errors to `isError: true`. Add a `default` branch when switching on `ToolContent.type`.
8. Prompts: filter exports with `isPrompt(x)` + `isSupportedPromptVersion(x)` and reject duplicate
   names. For `prompts/list`, derive `arguments` from the `args` object shape (field name,
   `.describe()` text, `required` unless optional/defaulted). On `prompts/get`: check
   `getMissingEnv`, validate with `prompt.args["~standard"].validate(args)`, call
   `render(value, { signal })`, then normalise: string → one `user` text message, array →
   `messages`, object with a `messages` array → the result as is.
9. Run uploaded code isolated (worker/child process with no secrets, or a container).

## Releasing

`npm run build && npm test`, then `npm pack --dry-run` to inspect the tarball.
Publish from CI with `npm publish --provenance --access public`.
Stay on `0.x` until real tools run in production. Breaking contract changes bump `apiVersion`.
